from setuptools import setup, find_packages


setup(
    name='dags',
    version='0.1',
    package_dir={'': 'dags'},
    packages=find_packages('dags'),
    include_package_data=True,
    install_requires=[],
    scripts=['bin/pycheck'],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Environment :: Web Environment',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: BSD License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
    ],
    zip_safe=True,
)

